# Gerador de códigos

Para inicializar o projeto, crie um arquivo chamado banco.sqlite na raiz deste repositório.

Após tê-lo feito, execute o código SQL contido no arquivo `database-create.sql` para criar a tabela.

Altere o arquivo `.env.dist` com valores que façam sentido e renomeie-o para `.env`

## Docker

Junto a este projeto há um `Dockerfile` com o ambiente necessário para rodar tanto os testes quanto o código real do mesmo.